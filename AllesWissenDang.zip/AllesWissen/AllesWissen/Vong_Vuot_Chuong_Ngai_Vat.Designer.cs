﻿namespace AllesWissen
{
    partial class Vong_Vuot_Chuong_Ngai_Vat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbScoreTeam1 = new System.Windows.Forms.Label();
            this.lbScoreTeam2 = new System.Windows.Forms.Label();
            this.lbScoreTeam3 = new System.Windows.Forms.Label();
            this.lbAnswerTeam1 = new System.Windows.Forms.Label();
            this.lbAnswerTeam2 = new System.Windows.Forms.Label();
            this.lbAnswerTeam3 = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnRight = new System.Windows.Forms.Button();
            this.btnWrong = new System.Windows.Forms.Button();
            this.btnPause = new System.Windows.Forms.Button();
            this.btnNextRound = new System.Windows.Forms.Button();
            this.pbTimer = new System.Windows.Forms.ProgressBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbScoreTeam1
            // 
            this.lbScoreTeam1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbScoreTeam1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbScoreTeam1.ForeColor = System.Drawing.Color.Red;
            this.lbScoreTeam1.Location = new System.Drawing.Point(1772, 112);
            this.lbScoreTeam1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbScoreTeam1.Name = "lbScoreTeam1";
            this.lbScoreTeam1.Size = new System.Drawing.Size(323, 127);
            this.lbScoreTeam1.TabIndex = 8;
            this.lbScoreTeam1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbScoreTeam2
            // 
            this.lbScoreTeam2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbScoreTeam2.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbScoreTeam2.ForeColor = System.Drawing.Color.Red;
            this.lbScoreTeam2.Location = new System.Drawing.Point(1772, 428);
            this.lbScoreTeam2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbScoreTeam2.Name = "lbScoreTeam2";
            this.lbScoreTeam2.Size = new System.Drawing.Size(323, 127);
            this.lbScoreTeam2.TabIndex = 9;
            this.lbScoreTeam2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbScoreTeam3
            // 
            this.lbScoreTeam3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbScoreTeam3.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbScoreTeam3.ForeColor = System.Drawing.Color.Red;
            this.lbScoreTeam3.Location = new System.Drawing.Point(1772, 748);
            this.lbScoreTeam3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbScoreTeam3.Name = "lbScoreTeam3";
            this.lbScoreTeam3.Size = new System.Drawing.Size(323, 127);
            this.lbScoreTeam3.TabIndex = 10;
            this.lbScoreTeam3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbAnswerTeam1
            // 
            this.lbAnswerTeam1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbAnswerTeam1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAnswerTeam1.ForeColor = System.Drawing.Color.Red;
            this.lbAnswerTeam1.Location = new System.Drawing.Point(1296, 112);
            this.lbAnswerTeam1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbAnswerTeam1.Name = "lbAnswerTeam1";
            this.lbAnswerTeam1.Size = new System.Drawing.Size(426, 127);
            this.lbAnswerTeam1.TabIndex = 11;
            this.lbAnswerTeam1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbAnswerTeam2
            // 
            this.lbAnswerTeam2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbAnswerTeam2.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAnswerTeam2.ForeColor = System.Drawing.Color.Red;
            this.lbAnswerTeam2.Location = new System.Drawing.Point(1296, 428);
            this.lbAnswerTeam2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbAnswerTeam2.Name = "lbAnswerTeam2";
            this.lbAnswerTeam2.Size = new System.Drawing.Size(426, 127);
            this.lbAnswerTeam2.TabIndex = 12;
            this.lbAnswerTeam2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbAnswerTeam3
            // 
            this.lbAnswerTeam3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbAnswerTeam3.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAnswerTeam3.ForeColor = System.Drawing.Color.Red;
            this.lbAnswerTeam3.Location = new System.Drawing.Point(1296, 748);
            this.lbAnswerTeam3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbAnswerTeam3.Name = "lbAnswerTeam3";
            this.lbAnswerTeam3.Size = new System.Drawing.Size(426, 127);
            this.lbAnswerTeam3.TabIndex = 13;
            this.lbAnswerTeam3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(57, 473);
            this.btnStart.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(136, 60);
            this.btnStart.TabIndex = 15;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnRight
            // 
            this.btnRight.Location = new System.Drawing.Point(110, 620);
            this.btnRight.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnRight.Name = "btnRight";
            this.btnRight.Size = new System.Drawing.Size(242, 98);
            this.btnRight.TabIndex = 16;
            this.btnRight.Text = "Right";
            this.btnRight.UseVisualStyleBackColor = true;
            // 
            // btnWrong
            // 
            this.btnWrong.Location = new System.Drawing.Point(697, 620);
            this.btnWrong.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnWrong.Name = "btnWrong";
            this.btnWrong.Size = new System.Drawing.Size(242, 98);
            this.btnWrong.TabIndex = 17;
            this.btnWrong.Text = "Wrong";
            this.btnWrong.UseVisualStyleBackColor = true;
            // 
            // btnPause
            // 
            this.btnPause.Location = new System.Drawing.Point(360, 473);
            this.btnPause.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPause.Name = "btnPause";
            this.btnPause.Size = new System.Drawing.Size(136, 60);
            this.btnPause.TabIndex = 18;
            this.btnPause.Text = "Pause";
            this.btnPause.UseVisualStyleBackColor = true;
            // 
            // btnNextRound
            // 
            this.btnNextRound.Location = new System.Drawing.Point(369, 748);
            this.btnNextRound.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnNextRound.Name = "btnNextRound";
            this.btnNextRound.Size = new System.Drawing.Size(204, 65);
            this.btnNextRound.TabIndex = 19;
            this.btnNextRound.Text = "Next Round";
            this.btnNextRound.UseVisualStyleBackColor = true;
            // 
            // pbTimer
            // 
            this.pbTimer.Location = new System.Drawing.Point(13, 383);
            this.pbTimer.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pbTimer.Name = "pbTimer";
            this.pbTimer.Size = new System.Drawing.Size(1236, 35);
            this.pbTimer.TabIndex = 20;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(697, 473);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 60);
            this.button1.TabIndex = 21;
            this.button1.Text = "Pause";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // Vong_Vuot_Chuong_Ngai_Vat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2148, 960);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pbTimer);
            this.Controls.Add(this.btnNextRound);
            this.Controls.Add(this.btnPause);
            this.Controls.Add(this.btnWrong);
            this.Controls.Add(this.btnRight);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.lbAnswerTeam3);
            this.Controls.Add(this.lbAnswerTeam2);
            this.Controls.Add(this.lbAnswerTeam1);
            this.Controls.Add(this.lbScoreTeam3);
            this.Controls.Add(this.lbScoreTeam2);
            this.Controls.Add(this.lbScoreTeam1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Vong_Vuot_Chuong_Ngai_Vat";
            this.Text = "Vong_Vuot_Chuong_Ngai_Vat";
            this.Load += new System.EventHandler(this.Vong_Vuot_Chuong_Ngai_Vat_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbScoreTeam1;
        private System.Windows.Forms.Label lbScoreTeam2;
        private System.Windows.Forms.Label lbScoreTeam3;
        private System.Windows.Forms.Label lbAnswerTeam1;
        private System.Windows.Forms.Label lbAnswerTeam2;
        private System.Windows.Forms.Label lbAnswerTeam3;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnRight;
        private System.Windows.Forms.Button btnWrong;
        private System.Windows.Forms.Button btnPause;
        private System.Windows.Forms.Button btnNextRound;
        private System.Windows.Forms.ProgressBar pbTimer;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button button1;
    }
}